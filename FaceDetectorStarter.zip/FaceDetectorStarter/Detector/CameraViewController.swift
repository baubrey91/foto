

//
//  CameraViewController.swift
//  Detector
//
//  Created by Gregg Mojica on 8/22/16.
//  Copyright © 2016 Gregg Mojica. All rights reserved.
//

import UIKit

class CameraViewController: UIViewController {
    @IBOutlet var imageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func takePhoto(sender: AnyObject) {
    }
 
    
   }
